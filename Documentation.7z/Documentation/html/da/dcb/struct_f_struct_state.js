var struct_f_struct_state =
[
    [ "index", "da/dcb/struct_f_struct_state.html#a8c5273292e9b3d76faabd09a7d716983", null ],
    [ "NameOfState", "da/dcb/struct_f_struct_state.html#a07865745b8eae22edb1be14eb06e6df7", null ],
    [ "StateSClass", "da/dcb/struct_f_struct_state.html#aac237972bb346278b12cb910f7467f0f", null ]
];